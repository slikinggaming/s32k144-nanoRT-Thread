/* ###################################################################
**     Filename    : main.c
**     Processor   : S32K1xx
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file main.c
** @version 01.00
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */


/* Including necessary module. Cpu.h contains other modules needed for compiling.*/
#include "Cpu.h"
#include <rthw.h>


  volatile int exit_code = 1;

/* User includes (#include below this line is not maintained by Processor Expert) */

/*! 
  \brief The main function for the project.
  \details The startup initialization sequence is the following:
 * - startup asm routine
 * - main()
*/
#define THREAD_PRIORITY      25
#define THREAD_STACK_SIZE    1024
#define THREAD_TIMESLICE     5

ALIGN(8)
static rt_uint8_t main_stack[RT_MAIN_THREAD_STACK_SIZE];
struct rt_thread thread1;
/* �߳���� */
void thread1_entry(void *parameter)
{
    int i;
    rt_thread_mdelay(1000);
    for(;;)
    {
    	 for(int i=0;i<10;i++)
    		  {
    			  	  int a = 9;
    			  	  int b = 3;
    			  	  int c = 0;

    			  	  c = a+b;
    		  }
    	rt_thread_mdelay(10);
    }
}

int dynmem_sample(void)
{
	rt_thread_t tid;
	rt_err_t result;

	    tid = &thread1;

	    result = rt_thread_init(tid, "thread1", thread1_entry, RT_NULL,
	    		main_stack, sizeof(main_stack), 3, 10);
	    RT_ASSERT(result == RT_EOK);

        rt_thread_startup(tid);
    return 0;
}

int main(void)
{
  /* Write your local variable definition here */

  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  #ifdef PEX_RTOS_INIT
    PEX_RTOS_INIT();                   /* Initialization of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */
  /* For example: for(;;) { } */

  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
    dynmem_sample();
  for(;;) {

	  for(int i=0;i<10;i++)
	  {
		  	  int a = 9;
		  	  int b = 3;
		  	  int c = 0;

		  	  c = a+b;
	  }
	  rt_thread_mdelay(10);
  }
  return exit_code;
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.1 [05.21]
**     for the NXP S32K series of microcontrollers.
**
** ###################################################################
*/
